function ReserveContent() {
  return (
    <div className="reserve-text">
  		<h2>Book a table</h2>
      <p>
        Lorem ipsum dolor sit, amet consectetur adipisicing elit. Pariatur
        itaque sint ad nobis nesciunt dicta nam minus, distinctio quae
        eveniet quia placeat, cupiditate, doloribus repellendus provident.
        Explicabo distinctio inventore necessitatibus!
      </p>
      <p>
        Lorem ipsum dolor sit, amet consectetur adipisicing elit. Pariatur
        itaque sint ad nobis nesciunt dicta nam minus, distinctio quae
      </p>
      <p>
        <a href="tel:1-989-233-213" className="tel">
          +1 989-233-213
        </a>
        <br></br>
      <a href="mailto:little@lemonresto.com" className="mail">
        little@lemonresto.com
      </a>
      </p>
    </div>
  );
}

export default ReserveContent;
